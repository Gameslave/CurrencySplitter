﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CurrencySplitter
{
    class Currency
    {
        public int Platinum;
        public int Gold;
        public int Electrum;
        public int Silver;
        public int Copper;
    }
}
