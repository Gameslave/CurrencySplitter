﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CurrencySplitter
{
    static class CurrencyExchange
    {
        public static int PLATINUM = 1000;
        public static int GOLD = 100;
        public static int ELECTRUM = 50;
        public static int SILVER = 10;
        public static int COPPER = 1;
    }
}